import { Smartphone, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";

interface GoogleFitConnectProps {
  userId?: string;
}

export function GoogleFitConnect({ userId }: GoogleFitConnectProps) {
  return (
    <div className="space-y-4">
      {/* Status */}
      <div className="p-4 rounded-lg bg-health-amber/5 border border-health-amber/20">
        <div className="flex items-start gap-3">
          <Smartphone className="w-5 h-5 text-health-amber mt-0.5" />
          <div>
            <p className="text-sm font-medium text-foreground">Native App Required</p>
            <p className="text-xs text-muted-foreground mt-1">
              Google Fit / Health Connect integration requires a native Android app. 
              This feature will automatically sync the following data when running as a native app:
            </p>
          </div>
        </div>
      </div>

      {/* Data types that will be synced */}
      <div className="grid grid-cols-2 gap-2">
        {[
          { label: "Steps", icon: "👟", desc: "Daily step count" },
          { label: "Heart Rate", icon: "❤️", desc: "Continuous BPM" },
          { label: "Sleep", icon: "😴", desc: "Sleep duration & stages" },
          { label: "Calories", icon: "🔥", desc: "Calories burned" },
          { label: "Distance", icon: "📏", desc: "Walking/running km" },
          { label: "Activity", icon: "🏃", desc: "Exercise sessions" },
        ].map((item) => (
          <div key={item.label} className="p-3 rounded-lg bg-secondary/20 border border-border">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-lg">{item.icon}</span>
              <span className="text-sm font-medium text-foreground">{item.label}</span>
            </div>
            <p className="text-xs text-muted-foreground">{item.desc}</p>
          </div>
        ))}
      </div>

      {/* Setup guide */}
      <div className="p-4 rounded-lg bg-secondary/20 border border-border">
        <p className="text-sm font-medium text-foreground mb-2">Setup Steps:</p>
        <ol className="text-xs text-muted-foreground space-y-1.5 list-decimal list-inside">
          <li>Export project to GitHub via Settings</li>
          <li>Install Capacitor for native Android build</li>
          <li>Configure Google Cloud Console for Health Connect API</li>
          <li>Add Health Connect permissions to AndroidManifest.xml</li>
          <li>Build and deploy native Android APK</li>
        </ol>
      </div>

      <Button variant="outline" className="w-full" disabled>
        <Smartphone className="w-4 h-4 mr-2" />
        Available in Native App
      </Button>

      <p className="text-xs text-center text-muted-foreground">
        Use Voice Log or Camera Heart Rate for browser-based data collection
      </p>
    </div>
  );
}
